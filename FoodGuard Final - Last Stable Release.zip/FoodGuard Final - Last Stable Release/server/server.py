from fastapi import FastAPI, File, UploadFile, HTTPException
from io import BytesIO
import easyocr
from PIL import Image
import traceback

app = FastAPI()

# Create OCR object
reader = easyocr.Reader(['en'], gpu=False)

# Text recognition request function
@app.post("/recognize/")
async def recognize_text(file: UploadFile = File(...)):
    try:
        # Read img
        image_data = await file.read()
        
        # Text recognition
        result = reader.readtext(image_data)
        
        # Get text after the process
        recognized_text = [detection[1] for detection in result]
        print([detection[1] for detection in result])
        
        # Send answer to user
        return {"Result": recognized_text}
    
    except Exception as e:
        # Error log
        error_message = f"Error: {str(e)}\n{traceback.format_exc()}"
        print(error_message)
        
        # Send answer with error 500
        raise HTTPException(status_code=500, detail="Error on server. Please try again.")