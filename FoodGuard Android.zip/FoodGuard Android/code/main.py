# KiVy Import
from kivy.uix.camera import Camera

# KiVyMD import
from kivy.lang import Builder
from kivymd.app import MDApp

# Widget import
from kivy.uix.widget import Widget

# Snackback import
from kivymd.uix.snackbar import (
    MDSnackbar,
    MDSnackbarSupportingText,
    MDSnackbarText
)

# Button import
from kivymd.uix.button import (
    MDButton,
    MDButtonText,
    MDIconButton
)

# Divider import
from kivymd.uix.divider import MDDivider

# List import
from kivymd.uix.list import (
    MDListItem,
    MDListItemLeadingIcon,
    MDListItemSupportingText,
    MDListItemHeadlineText
)

# Dialog import
from kivymd.uix.dialog import (
    MDDialog,
    MDDialogIcon,
    MDDialogHeadlineText,
    MDDialogButtonContainer,
    MDDialogSupportingText,
    MDDialogContentContainer
)

# Other Imports
import webbrowser
import time
import requests

### ===== Find scrip dir and import JSON with settings ===== ###
import os
from kivy.storage.jsonstore import JsonStore

# Get script dir
script_dir = os.path.dirname(os.path.abspath(__file__))

# Set JSON Path
settings_path = os.path.join(script_dir, 'settings.json')
store = JsonStore(settings_path)

# Set settings variables
wordlist = store.get('settings')['words']
amount = store.get('settings')['amount']
if_welcomed = store.get('settings')['welcomed']


### ===== App code ===== ###
class MainApp(MDApp):
    def build(self):
        self.theme_cls.primary_palette = "Olive"  # App color palette
        return Builder.load_file('ui.kv')  # Load UI file
    
    # Bootup functions
    def on_start(self):
        self.title = "FoodGuard" # App title

        # Camera turn on
        self.root.ids.idcamera.play = True
        self.updatelist()

        # Welcomed check
        if if_welcomed == 1:
            print('\033[105mUser was welcomed before.\033[0m')
        else:
            print('\033[105mMet a new user!\033[0m')
            self.show_welcome()

    # Update list
    def updatelist(self):

        # Remove old list
        list_container = self.root.ids.listid
        list_container.clear_widgets()

        for word in wordlist:
            
            # Get id
            list_container = self.root.ids.listid

            # Item to add
            item = MDListItem()

            # MDListItemHeadlineText
            headline_text = MDListItemHeadlineText(
                text=word,
            )
            item.add_widget(headline_text)

            # MDIconButton
            delete_button = MDIconButton(
                icon="delete",
                on_release=
                lambda x, item=item, word=word: self.remove(item, word), # Item remove
            )
            item.add_widget(delete_button)

            # Adding item
            list_container.add_widget(item)

            print("\033[102mList in UI updated\033[0m") # TTD



### ===== Functions ===== ###

    # Remove
    def remove(self, item, word):
        print("\033[44mRemove button pressed\033[0m") # TTD

        word_to_remove = word

        # Check if word exists
        if word_to_remove in wordlist:
            wordlist.remove(word_to_remove)
            word_amount = store.get('settings')['amount']
            word_amount -= 1
            upd_welcome = 1
            store.put('settings', words=wordlist, amount=word_amount, welcomed=upd_welcome) # Update wordlist in JSON

        print(f'\033[102mRemoving item:\033[0m {word}')  #TTD

        self.updatelist()

    # Add
    def add(self):
        print("\033[44mAdd button pressed\033[0m") # TTD

        text_to_add = self.root.ids.entry.text.strip()
        print(f'\033[102mText to add:\033[0m {text_to_add}') # TTD

        # Check entry to empty
        if not text_to_add:
            print(f'\033[41mError: input field is empty or contains only spaces.\033[0m') # TTD
            self.error_empty()
            self.root.ids.entry.text = "" # Empty entry
            return

        lower_text = text_to_add.lower() # Text to lowercase

        ### Adding word to JSON
        # Check if word doesn't exist
        if lower_text not in wordlist:
            self.root.ids.entry.text = "" # Empty entry
            word_amount = store.get('settings')['amount']
            wordlist.append(lower_text) # Adding word
            word_amount += 1 # +1 to amount
            upd_welcome = 1
            store.put('settings', words=wordlist, amount=word_amount, welcomed=upd_welcome)

            self.updatelist()

        else:
            print(f'\033[41mError: list already contains the item.\033[0m') # TTD
            self.error_already()

    # Clean all list
    def clean(self):

        # Clear wordlist
        wordlist.clear()

        # Set amount to 0
        amount = 0
        upd_welcome = 1
        store.put('settings', words=wordlist, amount=amount, welcomed=upd_welcome)

        self.updatelist()

    # Website btn
    def website(self):
        webbrowser.open("https://foodguard.tilda.ws/")


### ===== Scan Functions ===== ###

    # Scan
    def scan(self):
        print("\033[44mScan button pressed\033[0m")  # TTD

        # Захват изображения с камеры
        camera = self.root.ids['idcamera']
        timestr = time.strftime("%Y%m%d_%H%M%S")
        image_path = os.path.join(script_dir, f"FG_SCAN_{timestr}.png")
        camera.export_to_png(image_path)
        print("\033[47mCaptured\033[0m")

        # Отправка изображения на сервер API
        try:
            api_url = "http://YOUR-IP:YOUR-PORT/recognize/"   #CHANGE
            with open(image_path, 'rb') as image_file:
                files = {'file': ('image.png', image_file, 'image/png')}
                response = requests.post(api_url, files=files)

            # Обработка ответа от API
            if response.status_code == 200:
                recognized_text = response.json().get("Result", [])
                if recognized_text:
                    print("\033[42mText is recognized!\033[0m")
                    lower_result = " ".join([text.lower() for text in recognized_text])
                    print(f"\033[42mFull recognized text:\033[0m {lower_result}")
                    self.compare(lower_result, wordlist)
                else:
                    print("\033[41mNo text recognized!\033[0m")
                    self.scan_notext()
            else:
                print(f"\033[41mAPI Error: {response.status_code}\033[0m")
                self.scan_error()

        except Exception as e:
            print(f"\033[41mError during API request: {e}\033[0m")
            self.scan_error()

        # Удаление временного файла
        if os.path.exists(image_path):
            os.remove(image_path)
            print("\033[47mFile was successfully deleted.\033[0m")
        else:
            print("\033[41mERROR: File doesn't exist.\033[0m")


    # Text comparison
    def compare(self, lower_result, wordlist):
        print("\033[47mStarting compare.\033[0m")

        # Compare
        matched_words = [phrase for phrase in wordlist if phrase in lower_result]

        # Print matched words
        if matched_words:
            print("\033[42mMatched words/phrases: \033[0m", matched_words)
            self.scan_warn(matched_words)
        else:
            print("\033[41mNo matches found.\033[0m")
            self.scan_nothing()


    # Scan error (not recognized)
    def scan_error(self):

        self.md_dialog = MDDialog(
            MDDialogHeadlineText(text="Error!", halign="left"),
            MDDialogSupportingText(text="Scan failed! If you have any problems, visit project's website — it may help you!", halign="left"),
            MDDialogButtonContainer(
                Widget(),
                MDButton(
                    MDButtonText(text="No, thanks"), style="text", on_release=self.cancle),
                MDButton(
                    MDButtonText(text="Visit the website"), style="text", on_release=self.yes_watch),
                spacing="8dp", ), size_hint=(0.9, None),)
        self.md_dialog.open()

    # Result (nothing)
    def scan_nothing(self):

        self.md_dialog = MDDialog(
            MDDialogHeadlineText(text="Nothing!", halign="left"),
            MDDialogSupportingText(text="No matches were found with your list! Try again if you are sure that this is an error.", halign="left"),
            MDDialogButtonContainer(
                MDButton(
                    MDButtonText(text="Ok"), style="text", on_release=self.cancle),
                spacing="8dp", ), size_hint=(0.9, None),)
        self.md_dialog.open()




    # Result (notext)
    def scan_notext(self):

        self.md_dialog = MDDialog(
            MDDialogHeadlineText(text="No text!", halign="left"),
            MDDialogSupportingText(text="It looks like the scanner didn't find the text in the image! Try again if you think it's a mistake.", halign="left"),
            MDDialogButtonContainer(
                MDButton(
                    MDButtonText(text="Ok"), style="text", on_release=self.cancle),
                spacing="8dp", ), size_hint=(0.9, None),)
        self.md_dialog.open()





    # Result (match)
    def scan_warn(self, matched_words):

        matched_words_str = ', '.join(matched_words)

        self.md_dialog = MDDialog(
            MDDialogHeadlineText(text="Match was found!", halign="left"),
            MDDialogSupportingText(text=f"It looks like this product contains the following ingredients:\n{matched_words_str}", halign="left"),
            MDDialogButtonContainer(
                MDButton(
                    MDButtonText(text="Ok"), style="text", on_release=self.cancle),
                spacing="8dp", ), size_hint=(0.9, None),)
        self.md_dialog.open()



### ===== Notifications ===== ###

   # Adding error (already)
    def error_already(self):
        snackbar = MDSnackbar(
            MDSnackbarSupportingText(
                text="This item has already been added!",
            ),
            orientation="horizontal",
            pos_hint={"center_x": 0.5},
            size_hint_x=0.5,
        )
        snackbar.open()


    # Adding error (empty)
    def error_empty(self):
        snackbar = MDSnackbar(
            MDSnackbarText(
                text="The input field is empty!",
            ),
            orientation="horizontal",
            pos_hint={"center_x": 0.5},
            size_hint_x=0.5,
        )
        snackbar.open()


    # Show app info
    def show_info(self):
        MDDialog(
            # Icon
            MDDialogIcon(
                icon="progress-question",
            ),
            # Headline text
            MDDialogHeadlineText(
                text="App information",
            ),
            # Content
            MDDialogContentContainer(
                MDDivider(),

                MDListItem(
                    MDListItemLeadingIcon(
                        icon="open-in-app",
                    ),
                    MDListItemSupportingText(
                        text="Version: 1.2",
                    ),
                    theme_bg_color="Custom",
                    md_bg_color=self.theme_cls.transparentColor,
                ),

                MDListItem(
                    MDListItemLeadingIcon(
                        icon="github",
                    ),
                    MDListItemSupportingText(
                        text="GitHub: pythonCBK",
                    ),
                    theme_bg_color="Custom",
                    md_bg_color=self.theme_cls.transparentColor,
                ),

                MDDivider(),
                orientation="vertical",
            ), size_hint=(0.9, None),

        ).open()


    # Clean warning
    def show_warn(self):
        self.md_dialog = MDDialog(
            MDDialogHeadlineText(text="Warning!", halign="left"),
            MDDialogSupportingText(text=f"This action will reset your list. Are you sure you want to continue?", halign="left"),
            MDDialogButtonContainer(
                Widget(),
                MDButton(
                    MDButtonText(text="Cancel"), style="text", on_release=self.cancle),
                MDButton(
                    MDButtonText(text="Continue"), style="text", on_release=self.clean_continue),
                spacing="8dp", ), size_hint=(0.9, None))
        self.md_dialog.open()

    # Cancle
    def cancle(self, obj):
        print("\033[44mCancel button pressed\033[0m") #TTD
        self.md_dialog.dismiss()
        
    # Continue
    def clean_continue(self, obj):
        print("\033[44mContinue button pressed\033[0m") #TTD
        self.md_dialog.dismiss()
        self.clean()

    # Welcome message
    def show_welcome(self):

        # Welcomed update
        upd_welcome = 1
        store.put('settings', words=wordlist, amount=amount, welcomed=upd_welcome)

        self.md_dialog = MDDialog(
            MDDialogHeadlineText(text="Welcome!", halign="left"),
            MDDialogSupportingText(text="It looks like this is your first time using Food Guard. We recommend to visit project's website to avoid problems when using it.", halign="left"),
            MDDialogButtonContainer(
                Widget(),
                MDButton(
                    MDButtonText(text="No, thanks"), style="text", on_release=self.cancle),
                MDButton(
                    MDButtonText(text="Visit the website"), style="text", on_release=self.yes_watch),
                spacing="8dp", ), size_hint=(0.9, None),)
        self.md_dialog.open()

    # Watch tutorial
    def yes_watch(self, obj):
        print("\033[44mWatch tutorial button pressed\033[0m")
        self.md_dialog.dismiss()
        self.website()




### ===== App debugging ===== ###
print('\033[45m###=====APP DEBBUGING=====###\033[0m')
print(f'\033[105mScript directory:\033[0m {script_dir}')  #TTD - script dir
print(f"\033[105mWordlist:\033[0m {store.get('settings')['words']}")  # TTD - prints wordlist
print(f"\033[105mWords amount:\033[0m {store.get('settings')['amount']}")  # TTD - prints words amount



MainApp().run()